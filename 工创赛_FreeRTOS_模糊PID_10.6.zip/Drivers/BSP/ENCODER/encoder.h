#ifndef __ENCODER_H
#define __ENCODER_H

#include "./BSP/TIMER/btim.h"


void Reading(int16_t *L_Val,int16_t *R_Val);
void Readingback(int16_t *L_Val,int16_t *R_Val);
#endif  

