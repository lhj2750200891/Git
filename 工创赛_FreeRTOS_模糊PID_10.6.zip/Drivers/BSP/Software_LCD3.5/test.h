#ifndef __TEST_H__
#define __TEST_H__

#include "stdlib.h"

void LCD_Static_Show(void);
void LCD_Dynamic_Show(void);
void K210_Number_Show(void);
void LCD_Number123_Show(void);
void LCD_Number132_Show(void);
void LCD_Number213_Show(void);
void LCD_Number231_Show(void);
void LCD_Number312_Show(void);
void LCD_Number321_Show(void);
void LCD_NumberShow_123(void);
void LCD_NumberShow_132(void);
void LCD_NumberShow_213(void);
void LCD_NumberShow_231(void);
void LCD_NumberShow_312(void);
void LCD_NumberShow_321(void);
#endif
