#include "./BSP/SRAM/sram.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"

int XmRamInit(void);
