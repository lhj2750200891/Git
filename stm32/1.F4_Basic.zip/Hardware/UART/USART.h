#ifndef __LED_H
#define __LED_H

#include"main.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);

#endif
