#ifndef __DELAY_H
#define __DELAY_H

#include "sys.h"

void delay_us(unsigned int nus);

#endif
