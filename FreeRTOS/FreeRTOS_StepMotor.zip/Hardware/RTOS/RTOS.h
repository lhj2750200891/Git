#ifndef __RTOS_H
#define __RTOS_H

#include "stdint.h"
void freertos_demo(void);
void StartDefaultTask(void *argument);
#endif
