#ifndef __TEST_H__
#define __TEST_H__

#include "stdlib.h"

void LCD_Static_Show(void);
void LCD_Dynamic_Show(void);
void Number_Show(void);
#endif
